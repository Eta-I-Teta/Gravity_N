from engine.classes import *
from engine.defs import *
import json

if __name__ == "__main__":
    #argparse
    

    #demo
    pass

print([1,2]+[2,1])
"""earth = SpaceObject(radius=25e6, color=(100, 100, 255), coordinates=[10e6, 500e6], mass=1)
sun = SpaceObject(radius=25e6, color=(255, 100, 50), coordinates=[17e6, 1e6], mass=10**35)

space = [earth, sun]

acceleration_calculation(space)
print(earth.acceleration)"""